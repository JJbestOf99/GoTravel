# GoTravel 🚀 
Aplicación web sobre una agencia de viajes realizada para la asignatura de Programación web del grado de Ingeniería Informática en la UCAM

## Tecnologías 🛠️ 
* Front-end : HTML, CSS, Javascript 
* Back-end : PHP, XAMPP

## Video de demostración 🖥️
https://www.youtube.com/watch?v=7MSY0veVUkU&ab_channel=FranciscoRosasdelOlmo

## Autores ✒️ 
* Francisco Rosas del Olmo 
* Juan José López López
